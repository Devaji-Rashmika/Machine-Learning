# Forest Fire Risk Prediction — India

Complete frontend + FastAPI backend for the academic/demo Forest Fire Risk Prediction project.

## Project structure

```text
forest_fire_risk_prediction_india/
├── frontend/
│   └── index.html
├── backend/
│   ├── main.py
│   ├── requirements.txt
│   └── state_profiles.json
└── README.md
```

## 1. Requirements

Install Python 3.10+.

## 2. Start the backend

Open a terminal in the `backend` folder:

### Windows

```powershell
cd backend
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
uvicorn main:app --reload
```

If `py` is not available, use:

```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
uvicorn main:app --reload
```

You should see:

```text
Uvicorn running on http://127.0.0.1:8000
```

## 3. Check the backend

Open:

http://127.0.0.1:8000/docs

You should see the FastAPI Swagger documentation.

You can also check:

http://127.0.0.1:8000/api/health

## 4. Open the frontend

Double-click:

```text
frontend/index.html
```

The page will connect to:

```text
http://127.0.0.1:8000/api
```

Keep the backend terminal running while using the website.

## Features

- India state/UT risk map
- Month selection
- Temperature, humidity and rainfall sensitivity controls
- Click a map marker to predict that state
- Click approximately anywhere inside India to select the nearest state
- Single-location prediction
- Automatic climate values for selected state/month
- Manual weather sliders
- Optional current Open-Meteo weather
- Logistic Regression, Random Forest and Gradient Boosting model comparison
- Accuracy, precision, recall, F1 and ROC-AUC
- Feature importance
- FastAPI Swagger documentation

## Important academic limitation

This package is self-contained and therefore generates its calibration/training dataset from the included state reference profiles and a documented synthetic weather/risk relationship.

The resulting probabilities and model metrics are for an academic/demo application. They are **not** real-world fire occurrence probabilities and should not be presented as an official fire-warning system.

The "Use current Open-Meteo weather" button uses Open-Meteo over the internet. The rest of the application can run locally after Python dependencies are installed.
