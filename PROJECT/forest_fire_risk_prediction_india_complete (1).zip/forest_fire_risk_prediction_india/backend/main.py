from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Literal

import numpy as np
import requests
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

BASE = Path(__file__).resolve().parent
PROFILES = json.loads((BASE / "state_profiles.json").read_text(encoding="utf-8"))

MONTHS = [
    {"value": i, "name": name}
    for i, name in enumerate(
        ["January","February","March","April","May","June",
         "July","August","September","October","November","December"], 1
    )
]
MONTH_FACTOR = {1:0.10,2:0.14,3:0.24,4:0.38,5:0.48,6:0.30,
                7:0.05,8:0.02,9:0.08,10:0.20,11:0.30,12:0.16}

FEATURES = ["base_risk","month_factor","temperature_c","humidity_pct","wind_kmh","rainfall_mm"]
MODELS = {}
METRICS = {}
IMPORTANCES = {}
BEST_MODEL = "random_forest"

app = FastAPI(title="Forest Fire Risk Prediction India API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def default_weather(profile: dict, month: int) -> dict:
    # Academic calibration weather profile; not live observations.
    lat = profile["lat"]
    seasonal = math.cos((month - 4) / 12 * 2 * math.pi)
    temperature = 28 - abs(lat - 20) * 0.28 + 4 * seasonal
    humidity = 67 - 15 * seasonal + (6 if lat > 25 else 0)
    wind = 12 + 4 * math.sin((month + 1) / 12 * 2 * math.pi)
    rainfall = max(5, 115 - 95 * max(0, seasonal) + 35 * (1 - profile["base_risk"]))
    return {
        "temperature_c": round(clamp(temperature, 8, 46), 1),
        "humidity_pct": round(clamp(humidity, 15, 95), 1),
        "wind_kmh": round(clamp(wind, 1, 50), 1),
        "rainfall_mm": round(clamp(rainfall, 0, 900), 1),
    }

def fire_score(base, month_factor, temp, humidity, wind, rainfall):
    dryness = (
        2.4 * base
        + 0.95 * month_factor
        + 0.035 * (temp - 24)
        + 0.018 * (55 - humidity)
        + 0.010 * (wind - 10)
        - 0.0028 * rainfall
    )
    return dryness

def make_dataset(seed=42, n=5000):
    rng = np.random.default_rng(seed)
    X, y = [], []
    for _ in range(n):
        p = PROFILES[int(rng.integers(0, len(PROFILES)))]
        month = int(rng.integers(1, 13))
        w = default_weather(p, month)
        temp = w["temperature_c"] + rng.normal(0, 5)
        humidity = clamp(w["humidity_pct"] + rng.normal(0, 14), 5, 100)
        wind = clamp(w["wind_kmh"] + rng.normal(0, 7), 0, 80)
        rainfall = clamp(w["rainfall_mm"] + rng.normal(0, 55), 0, 900)
        score = fire_score(p["base_risk"], MONTH_FACTOR[month], temp, humidity, wind, rainfall)
        probability = 1 / (1 + math.exp(-4.0 * (score - 1.0)))
        label = int(rng.random() < probability)
        X.append([p["base_risk"], MONTH_FACTOR[month], temp, humidity, wind, rainfall])
        y.append(label)
    return np.asarray(X), np.asarray(y)

def train_models():
    X, y = make_dataset()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    MODELS["logistic_regression"] = Pipeline([
        ("scale", StandardScaler()),
        ("model", LogisticRegression(max_iter=1000, random_state=42))
    ])
    MODELS["random_forest"] = RandomForestClassifier(
        n_estimators=180, max_depth=10, min_samples_leaf=3, random_state=42
    )
    MODELS["gradient_boosting"] = GradientBoostingClassifier(
        n_estimators=140, max_depth=3, learning_rate=0.05, random_state=42
    )

    METRICS.clear()
    for name, model in MODELS.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        prob = model.predict_proba(X_test)[:, 1]
        METRICS[name] = {
            "label": name.replace("_", " ").title(),
            "accuracy": round(float(accuracy_score(y_test, pred)), 3),
            "precision": round(float(precision_score(y_test, pred, zero_division=0)), 3),
            "recall": round(float(recall_score(y_test, pred, zero_division=0)), 3),
            "f1": round(float(f1_score(y_test, pred, zero_division=0)), 3),
            "roc_auc": round(float(roc_auc_score(y_test, prob)), 3),
        }

    # Choose the model with the highest validation F1, breaking ties by ROC-AUC.
    global BEST_MODEL
    BEST_MODEL = max(METRICS, key=lambda k: (METRICS[k]["f1"], METRICS[k]["roc_auc"]))

    # Feature importance for the selected model.
    model = MODELS[BEST_MODEL]
    if BEST_MODEL == "logistic_regression":
        vals = np.abs(model.named_steps["model"].coef_[0])
        vals = vals / vals.sum()
    else:
        vals = model.feature_importances_
    IMPORTANCES.clear()
    IMPORTANCES[BEST_MODEL] = {f: round(float(v), 5) for f, v in zip(FEATURES, vals)}

train_models()

class PredictionRequest(BaseModel):
    state_code: str
    month: int = Field(ge=1, le=12)
    temperature_c: float
    humidity_pct: float = Field(ge=0, le=100)
    wind_kmh: float = Field(ge=0, le=150)
    rainfall_mm: float = Field(ge=0, le=2000)
    model: Literal["best", "logistic_regression", "random_forest", "gradient_boosting"] = "best"

def get_profile(code: str):
    for p in PROFILES:
        if p["code"].upper() == code.upper():
            return p
    raise HTTPException(status_code=404, detail=f"Unknown state/UT code: {code}")

def model_name(requested):
    return BEST_MODEL if requested == "best" else requested

def category(prob):
    if prob < 0.25:
        return "Low"
    if prob < 0.50:
        return "Moderate"
    if prob < 0.75:
        return "High"
    return "Very High"

@app.get("/")
def root():
    return {"message": "Forest Fire Risk Prediction India API", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "ok", "best_model": BEST_MODEL}

@app.get("/api/states")
def states():
    return {"months": MONTHS, "states": PROFILES}

@app.get("/api/climate/{state_code}/{month}")
def climate(state_code: str, month: int):
    if month < 1 or month > 12:
        raise HTTPException(status_code=400, detail="Month must be 1-12")
    p = get_profile(state_code)
    return {"state_code": p["code"], "state": p["name"], "month": month, **default_weather(p, month)}

@app.get("/api/map")
def map_data(
    month: int = Query(1, ge=1, le=12),
    temp_delta: float = 0,
    humidity_delta: float = 0,
    rainfall_scale: float = Query(1, ge=0, le=2),
):
    result = []
    counts = {"Low":0, "Moderate":0, "High":0, "Very High":0}
    model = MODELS[BEST_MODEL]

    for p in PROFILES:
        w = default_weather(p, month)
        temp = w["temperature_c"] + temp_delta
        humidity = clamp(w["humidity_pct"] + humidity_delta, 0, 100)
        rainfall = clamp(w["rainfall_mm"] * rainfall_scale, 0, 900)
        x = [[p["base_risk"], MONTH_FACTOR[month], temp, humidity, w["wind_kmh"], rainfall]]
        prob = float(model.predict_proba(x)[0,1])
        cat = category(prob)
        counts[cat] += 1
        result.append({
            "code": p["code"], "name": p["name"], "lat": p["lat"], "lon": p["lon"],
            "risk_pct": round(prob*100, 1), "probability": round(prob, 5), "category": cat
        })
    return {"month": month, "states": result, "counts": counts, "model": BEST_MODEL}

@app.post("/api/predict")
def predict(req: PredictionRequest):
    p = get_profile(req.state_code)
    name = model_name(req.model)
    model = MODELS[name]
    x = [[p["base_risk"], MONTH_FACTOR[req.month], req.temperature_c,
          req.humidity_pct, req.wind_kmh, req.rainfall_mm]]
    prob = float(model.predict_proba(x)[0,1])
    cat = category(prob)
    return {
        "state_code": p["code"], "state": p["name"], "risk_pct": round(prob*100, 1),
        "probability": round(prob, 5), "category": cat, "model_used": name
    }

@app.get("/api/metrics")
def metrics():
    return {"best_model": BEST_MODEL, "models": METRICS}

@app.get("/api/importances")
def importances():
    return IMPORTANCES

@app.get("/api/weather/live/{state_code}")
def live_weather(state_code: str):
    p = get_profile(state_code)
    # Open-Meteo has a public endpoint and needs no API key.
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": p["lat"], "longitude": p["lon"],
        "current": "temperature_2m,relative_humidity_2m,wind_speed_10m",
        "hourly": "precipitation",
        "forecast_days": 1,
        "timezone": "auto",
    }
    try:
        r = requests.get(url, params=params, timeout=8)
        r.raise_for_status()
        data = r.json()
        current = data.get("current", {})
        precipitation = data.get("hourly", {}).get("precipitation", [0])
        rain = float(sum(precipitation[:24]))
        return {
            "state_code": p["code"],
            "temperature_c": round(float(current.get("temperature_2m", 25)), 1),
            "humidity_pct": round(float(current.get("relative_humidity_2m", 60)), 1),
            "wind_kmh": round(float(current.get("wind_speed_10m", 10)), 1),
            "rainfall_mm": round(rain, 1),
            "source": "Open-Meteo",
        }
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Open-Meteo request failed: {exc}")
